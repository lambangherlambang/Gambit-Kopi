/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Chess } from 'chess.js';
import { Chart } from 'chart.js/auto';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Coffee, 
  ShieldCheck, 
  AlertTriangle, 
  Play, 
  Copy, 
  Download, 
  RefreshCw, 
  X, 
  User, 
  Award, 
  BarChart4, 
  Calendar, 
  Hash, 
  ChevronRight, 
  Flame, 
  CheckCircle,
  Clock
} from 'lucide-react';

// ==========================================
// INTERFACES & TYPES DEFINITION
// ==========================================

interface MoveAnalysis {
  san: string;          // Algebraic notation (e.g. e4)
  uci: string;          // UCI coordinates (e.g. e2e4)
  color: 'w' | 'b';
  evalBefore: number;   // Perspective is White's perspective
  evalAfter: number;    // Perspective is White's perspective
  cpl: number;          // Centipawn loss (>= 0)
  accuracy: number;     // Move accuracy [0, 100]
  moveClass: 'Brilliant' | 'Great' | 'Best' | 'Good' | 'Inaccuracy' | 'Mistake' | 'Blunder' | 'Book' | 'Forced';
  bestmove: string;     // Engin's recommended best move
  clock: number | null; // Clock time in seconds if available
  timeSpent: number | null; // Thinking time in seconds
  isEngineMatch: boolean; // Did player make the engine's best move
  complexity: number;   // Position complexity
  isSkipped: boolean;   // Omitted from ACPL/Accuracy calculation
  skipReason?: string;  // Reason skipped
}

interface PlayerStats {
  accuracy: number;
  acpl: number;
  bestMoveMatchPercent: number;
  brilliantCount: number;
  greatMoveCount: number;
  bestMoveCount: number;
  goodMoveCount: number;
  inaccuracyCount: number;
  mistakeCount: number;
  blunderCount: number;
  times: number[];
  avgTimeSpent: number;
  sdTimeSpent: number;
  hasClocks: boolean;
  isFlatTime: boolean;
  suspiciousScore: number;
}

interface AnalysisResults {
  whiteName: string;
  blackName: string;
  whiteRating: number;
  blackRating: number;
  date: string;
  event: string;
  whiteStats: PlayerStats;
  blackStats: PlayerStats;
  moves: MoveAnalysis[]; // Chronological sequence representing intermediate states
}

interface Verdict {
  status: 'GREEN' | 'YELLOW' | 'RED';
  title: string;
  reason: string;
  badgeClass: string;
  boxClass: string;
}

export default function App() {
  // ==========================================
  // STATE MANAGEMENT
  // ==========================================
  
  const [pgn, setPgn] = useState<string>('');
  const [whiteRating, setWhiteRating] = useState<number>(1200);
  const [blackRating, setBlackRating] = useState<number>(1200);
  const [engineDepth, setEngineDepth] = useState<number>(15);
  
  // App UI State
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [progressStep, setProgressStep] = useState<number>(0);
  const [progressTotal, setProgressTotal] = useState<number>(0);
  const [currentEvalProgress, setCurrentEvalProgress] = useState<string>('0.00');
  const [activeTab, setActiveTab] = useState<'w' | 'b'>('w');
  const [showWarningModal, setShowWarningModal] = useState<boolean>(false);
  const [showToast, setShowToast] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string>('');
  
  // Results State
  const [results, setResults] = useState<AnalysisResults | null>(null);
  
  // Engine References
  const stockfishRef = useRef<Worker | null>(null);
  const activeWorkersRef = useRef<Worker[]>([]);
  const chartRef = useRef<HTMLCanvasElement | null>(null);
  const chartInstanceRef = useRef<any>(null);

  // Default PGN for Anti-Cheat Demo
  const DEFAULT_PGN = `[Event "Gambit Kopi Cup"]
[White "npc1606 (1050)"]
[Black "Tonny077 (1793)"]
1. e4 {[%clk 0:15:00.1]} e5 {[%clk 0:15:00]} 2. Nf3 {[%clk 0:14:50]} Nc6 {[%clk 0:14:55]} 3. d4 {[%clk 0:14:42.6]} exd4 {[%clk 0:14:50]}`;

  // ==========================================
  // INITIAL LOAD & AUTO-LOAD FROM LOCAL STORAGE
  // ==========================================
  
  useEffect(() => {
    const savedPgn = localStorage.getItem('gambit_kopi_last_pgn');
    if (savedPgn) {
      setPgn(savedPgn);
    } else {
      setPgn(DEFAULT_PGN);
    }
    
    // Cleanup active worker on unmount
    return () => {
      if (stockfishRef.current) {
        stockfishRef.current.terminate();
      }
      activeWorkersRef.current.forEach((w) => {
        try {
          w.terminate();
        } catch (e) {}
      });
    };
  }, []);

  // Update ratings and player names dynamically when PGN content changes
  useEffect(() => {
    if (!pgn || pgn.trim() === '') return;
    try {
      const chess = new Chess();
      chess.loadPgn(pgn);
      const headers = chess.header();
      
      if (headers.WhiteElo) {
        const parsedWhite = parseInt(headers.WhiteElo, 10);
        if (!isNaN(parsedWhite)) setWhiteRating(parsedWhite);
      }
      if (headers.BlackElo) {
        const parsedBlack = parseInt(headers.BlackElo, 10);
        if (!isNaN(parsedBlack)) setBlackRating(parsedBlack);
      }
    } catch (e) {
      // Ignore intermediate parsing errors during PGN editing
    }
  }, [pgn]);

  // ==========================================
  // CHART RENDERING (Chart.js)
  // ==========================================

  useEffect(() => {
    if (!results || !chartRef.current) return;
    
    const activeStats = activeTab === 'w' ? results.whiteStats : results.blackStats;
    const labels = activeStats.times.map((_, i) => `Langkah ${i + 1}`);
    const data = activeStats.times;

    // Destroy existing chart to prevent canvas recycling crash
    if (chartInstanceRef.current) {
      chartInstanceRef.current.destroy();
    }

    const isFlatTime = activeStats.hasClocks && activeStats.sdTimeSpent < 1.5;
    const barBgColor = isFlatTime ? 'rgba(250, 65, 45, 0.8)' : 'rgba(139, 90, 43, 0.75)';
    const barBorderColor = isFlatTime ? '#fa412d' : '#8b5a2b';
    const barHoverBgColor = isFlatTime ? 'rgba(250, 65, 45, 0.95)' : 'rgba(160, 109, 59, 0.95)';

    const ctx = chartRef.current.getContext('2d');
    if (ctx) {
      chartInstanceRef.current = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: labels,
          datasets: [{
            label: 'Waktu Pikir (Detik)',
            data: data,
            backgroundColor: barBgColor,
            borderColor: barBorderColor,
            borderWidth: 2,
            borderRadius: 4,
            hoverBackgroundColor: barHoverBgColor
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: false
            },
            tooltip: {
              backgroundColor: '#2b2522',
              titleColor: '#f5efe6',
              bodyColor: '#bdaea5',
              borderColor: barBorderColor,
              borderWidth: 1,
              callbacks: {
                label: function(context) {
                  return `Durasi: ${context.parsed.y} detik`;
                }
              }
            }
          },
          scales: {
            x: {
              grid: {
                color: '#2b2522'
              },
              ticks: {
                color: '#bdaea5',
                font: {
                  family: 'Poppins'
                }
              }
            },
            y: {
              beginAtZero: true,
              grid: {
                color: '#2b2522'
              },
              ticks: {
                color: '#bdaea5',
                font: {
                  family: 'Poppins'
                }
              }
            }
          }
        }
      });
    }

    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
        chartInstanceRef.current = null;
      }
    };
  }, [results, activeTab]);

  // ==========================================
  // UTILS & METRIC HELPERS
  // ==========================================

  const showToastNotification = (message: string) => {
    setToastMessage(message);
    setShowToast(true);
    setTimeout(() => {
      setShowToast(false);
    }, 6000);
  };

  // Convert mate score in moves into centipawns perspective
  const convertMateToCp = (mate: number): number => {
    const sign = mate >= 0 ? 1 : -1;
    const N = Math.abs(mate);
    return sign * (10000 - 10 * N);
  };

  // Parse time stamps from PGN clock details
  const parseTimeToSeconds = (timeStr: string): number => {
    const parts = timeStr.split(':').map(Number);
    if (parts.length === 3) {
      const [h, m, s] = parts;
      return h * 3600 + m * 60 + s;
    } else if (parts.length === 2) {
      const [m, s] = parts;
      return m * 60 + s;
    } else if (parts.length === 1) {
      return parts[0];
    }
    return 0;
  };

  // Estimate the base starting time if TimeControl header isn't present
  const estimateBaseTime = (clocks: (number | null)[]): number => {
    for (const c of clocks) {
      if (c !== null && c > 0) {
        const commonBases = [60, 120, 180, 240, 300, 600, 900, 1800, 2700, 3600, 5400, 7200];
        let closest = c;
        let minDiff = Infinity;
        for (const base of commonBases) {
          const diff = Math.abs(c - base);
          if (diff < minDiff && diff < 60) {
            minDiff = diff;
            closest = base;
          }
        }
        return closest;
      }
    }
    return 900; // Default 15 minutes
  };

  // Safe Standard Deviation calculation
  const getStandardDeviation = (times: number[]): number => {
    if (times.length < 2) return 0;
    const n = times.length;
    const mean = times.reduce((a, b) => a + b, 0) / n;
    const variance = times.reduce((total, val) => total + Math.pow(val - mean, 2), 0) / n;
    return Math.sqrt(variance);
  };

  // ==========================================
  // INITIALIZE STOCKFISH WEB WORKER
  // ==========================================

  const initStockfish = (): Promise<Worker> => {
    return new Promise((resolve, reject) => {
      try {
        // Create Blob to import Stockfish from standard cdnjs
        const blobCode = `importScripts("https://cdnjs.cloudflare.com/ajax/libs/stockfish.js/10.0.2/stockfish.js");`;
        const blob = new Blob([blobCode], { type: "application/javascript" });
        const workerUrl = URL.createObjectURL(blob);
        const worker = new Worker(workerUrl);
        
        let isReady = false;
        const initTimeout = setTimeout(() => {
          if (!isReady) {
            worker.terminate();
            reject(new Error("Inisialisasi Stockfish Engine kedaluwarsa. Silakan periksa koneksi internet Anda."));
          }
        }, 15000);
        
        worker.onmessage = (e: MessageEvent) => {
          const line = e.data;
          if (typeof line === 'string') {
            if (line.includes('uciok') || line.includes('readyok')) {
              isReady = true;
              clearTimeout(initTimeout);
              resolve(worker);
            }
          }
        };
        
        worker.postMessage('uci');
        worker.postMessage('isready');
      } catch (err) {
        reject(err);
      }
    });
  };

  // ==========================================
  // EXTRACT CHESS DATA (PGN Parser)
  // ==========================================

  const parsePGN = (pgnString: string) => {
    const chess = new Chess();
    chess.loadPgn(pgnString);
    return chess;
  };

  // ==========================================
  // CORE ANALYSIS METHOD (Stockfish Loop)
  // ==========================================

  const analyzeGame = async () => {
    // EASTER EGG Check
    if (!pgn || pgn.trim() === '') {
      alert("Kopinya mana? PGN-nya kosong bray ☕. Paste dululah di textarea box.");
      return;
    }

    try {
      // Test parsing first
      const chess = parsePGN(pgn);
      
      // Close modal warn and start loaders
      setShowWarningModal(false);
      setIsAnalyzing(true);
      setResults(null);
      setProgressStep(0);
      setCurrentEvalProgress("0.00");

      const headers = chess.header();
      const movesHistory = chess.history({ verbose: true });
      const totalPositions = movesHistory.length + 1; // Start pos + all after-moves
      setProgressTotal(totalPositions);

      // Extract raw clock strings from PGN
      const clocks: (number | null)[] = new Array(movesHistory.length).fill(null);
      
      // Strict regex parser to capture clock comments matching moves
      const pgnClocksClean = pgn.replace(/\[[^\]]+\]/g, '');
      const moveCommentsRegex = /([a-zA-Z0-9x=+#-\/]+|O-O-O|O-O)\s*(?:\{([^}]*)\})?/g;
      let clkMatch;
      let moveIdx = 0;
      
      while ((clkMatch = moveCommentsRegex.exec(pgnClocksClean)) !== null) {
        const moveToken = clkMatch[1];
        const commentToken = clkMatch[2] || '';
        if (/^\d+(\.+\s*)?$/.test(moveToken)) continue;
        const isLegitMove = /^[a-hKQRBNPOo0-x=+#-\/!]+$/i.test(moveToken);
        if (!isLegitMove) continue;

        if (moveIdx < movesHistory.length) {
          if (commentToken) {
            const innerClk = commentToken.match(/\[%clk\s+([0-9:.]+)\s*\]/);
            if (innerClk) {
              clocks[moveIdx] = parseTimeToSeconds(innerClk[1]);
            }
          }
          moveIdx++;
        }
      }

      // Determine Time Control
      let baseTime = 900; // default 15m
      if (headers.TimeControl) {
        const tcPart = headers.TimeControl.split('+')[0];
        const tcSec = parseInt(tcPart, 10);
        if (!isNaN(tcSec)) baseTime = tcSec;
      } else {
        baseTime = estimateBaseTime(clocks);
      }

      // Initialize engine
      const worker = await initStockfish();
      stockfishRef.current = worker;

      // Extract all chronological FEN strings to analyze
      const fensToAnalyze: string[] = [];
      fensToAnalyze.push('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'); // Start FEN
      
      for (const m of movesHistory) {
        fensToAnalyze.push(m.after);
      }

      // All positions are needed since Rule 2 filter is removed
      const isFenNeeded = new Array(fensToAnalyze.length).fill(true);

      const rawEvaluations: number[] = new Array(fensToAnalyze.length).fill(0);
      const bestEngineMoves: string[] = new Array(fensToAnalyze.length).fill('');

      // Determine parallel worker capacity to leverage multiple CPU threads (up to 4)
      const maxWorkers = Math.min(4, fensToAnalyze.length);
      const workers: Worker[] = [];

      for (let w = 0; w < maxWorkers; w++) {
        const pWorker = await initStockfish();
        pWorker.postMessage('setoption name MultiPV value 3'); // Set MultiPV option (Rule 1)
        workers.push(pWorker);
      }
      activeWorkersRef.current = workers;
      // Keep first worker in stockfishRef for backwards compatibility
      stockfishRef.current = workers[0] || null;

      let fenIndex = 0;
      let completedCount = 0;

      await new Promise<void>((resolveParallel) => {
        const processNextFen = (workerObj: Worker, workerIdx: number) => {
          if (fenIndex >= fensToAnalyze.length) {
            return;
          }

          const currentTaskIndex = fenIndex++;
          const fen = fensToAnalyze[currentTaskIndex];

          // Check if FEN analysis is needed (all are needed since Rule 2 filter is removed)
          if (!isFenNeeded[currentTaskIndex]) {
            rawEvaluations[currentTaskIndex] = 0; // will be filled/smoothed or propagated later
            bestEngineMoves[currentTaskIndex] = '';
            completedCount++;
            setProgressStep(completedCount);
            if (completedCount === fensToAnalyze.length) {
              resolveParallel();
            } else {
              processNextFen(workerObj, workerIdx);
            }
            return;
          }

          // Heuristic/Game-over rapid cutoffs to avoid wasting thread time
          let preCalculatedScore: number | null = null;
          let preCalculatedBestMove: string | null = null;

          try {
            const checkChess = new Chess(fen);
            if (checkChess.isGameOver()) {
              if (checkChess.isCheckmate()) {
                const turnToMove = fen.includes(' b ') ? 'b' : 'w';
                preCalculatedScore = turnToMove === 'b' ? 10000 : -10000;
                preCalculatedBestMove = '(none)';
              } else {
                preCalculatedScore = 0;
                preCalculatedBestMove = '(none)';
              }
            } else {
              const legMoves = checkChess.moves({ verbose: true });
              if (legMoves.length === 0) {
                preCalculatedScore = 0;
                preCalculatedBestMove = '(none)';
              } else if (legMoves.length === 1) {
                // Forced / Single Legal Move: Instant perfect reply
                preCalculatedScore = fen.includes(' b ') ? -50 : 50;
                preCalculatedBestMove = `${legMoves[0].from}${legMoves[0].to}${legMoves[0].promotion || ''}`;
              }
            }
          } catch (e) {
            // Silently fallback to engine on parsing issues
          }

          if (preCalculatedScore !== null && preCalculatedBestMove !== null) {
            rawEvaluations[currentTaskIndex] = preCalculatedScore;
            bestEngineMoves[currentTaskIndex] = preCalculatedBestMove;
            completedCount++;
            setProgressStep(completedCount);

            if (completedCount === fensToAnalyze.length) {
              resolveParallel();
            } else {
              processNextFen(workerObj, workerIdx);
            }
            return;
          }

          let latestScore = 0;
          let latestBest = '';

          workerObj.onmessage = (e: MessageEvent) => {
            const line = e.data as string;
            if (line.startsWith('info') && line.includes('score')) {
              // Rule 1: We requested setoption name MultiPV value 3. 
              // The main chess score is in the multipv 1 line. Skip others to avoid overriding.
              if (line.includes('multipv ') && !line.includes('multipv 1 ')) {
                return;
              }

              const cpMatch = line.match(/score cp (-?\d+)/);
              const mateMatch = line.match(/score mate (-?\d+)/);
              const activeTurn = fen.includes(' b ') ? 'b' : 'w';

              if (cpMatch) {
                const cpVal = parseInt(cpMatch[1], 10);
                latestScore = activeTurn === 'w' ? cpVal : -cpVal;
              } else if (mateMatch) {
                const mateVal = parseInt(mateMatch[1], 10);
                const converted = convertMateToCp(mateVal);
                latestScore = activeTurn === 'w' ? converted : -converted;
              }

              const formattedVal = (latestScore / 100).toFixed(2);
              setCurrentEvalProgress(`${latestScore > 0 ? '+' : ''}${formattedVal}`);
            }

            if (line.startsWith('bestmove')) {
              const bestParts = line.split(' ');
              latestBest = bestParts[1];

              rawEvaluations[currentTaskIndex] = latestScore;
              bestEngineMoves[currentTaskIndex] = latestBest;

              completedCount++;
              setProgressStep(completedCount);

              if (completedCount === fensToAnalyze.length) {
                resolveParallel();
              } else {
                processNextFen(workerObj, workerIdx);
              }
            }
          };

          // Highly optimized Engine limits. Rule 1: go depth 18 movetime 2000 for depth 18, and 3000 for depth 20
          let moveTimeLimit = 800;
          if (engineDepth === 20) {
            moveTimeLimit = 3000; // 3.0 seconds (Chess.com/Lichess style Extreme Precision)
          } else if (engineDepth === 18) {
            moveTimeLimit = 2000;  // EXACT Rule 1 match: movetime 2000
          } else if (engineDepth === 15) {
            moveTimeLimit = 800;   // 800ms
          } else {
            moveTimeLimit = 400;   // 400ms
          }

          workerObj.postMessage(`position fen ${fen}`);
          workerObj.postMessage(`go depth ${engineDepth} movetime ${moveTimeLimit}`);
        };

        // Seed task to all initialized parallel threads
        for (let w = 0; w < workers.length; w++) {
          processNextFen(workers[w], w);
        }
      });

      // Terminate all parallel workers to free system resources
      workers.forEach((w) => {
        try {
          w.terminate();
        } catch (e) {}
      });
      activeWorkersRef.current = [];
      stockfishRef.current = null;

      // Propagate/fill in skipped FEN evaluations from neighboring non-skipped so they have stable CPL references
      for (let i = 0; i < rawEvaluations.length; i++) {
        if (!isFenNeeded[i]) {
          if (i > 0) {
            rawEvaluations[i] = rawEvaluations[i - 1];
          } else {
            rawEvaluations[i] = 30; // standard starting evaluation for white
          }
        }
      }

      // ==========================================
      // BACKEND COMPUTATION & ALIGNMENT
      // ==========================================

      const moveAnalyses: MoveAnalysis[] = [];
      
      // Let's analyze moves history one by one
      for (let k = 0; k < movesHistory.length; k++) {
        const move = movesHistory[k];
        const playerColor = move.color;
        
        // Eval before is the eval of position index k
        // Eval after is the eval of position index k+1
        const evalBefore = rawEvaluations[k];
        const evalAfter = rawEvaluations[k + 1];
        
        const playedUci = `${move.from}${move.to}${move.promotion || ''}`;
        const engineBest = bestEngineMoves[k];
        const isEngineMatch = playedUci === engineBest;

        // Complexity Check
        let complexity = 100;
        let isOnlyLegal = false;
        try {
          const checkChessAtK = new Chess(fensToAnalyze[k]);
          const piecesNum = checkChessAtK.board().flat().filter(p => p !== null).length;
          const legalMoves = checkChessAtK.moves({ verbose: true });
          complexity = (piecesNum * 4) + legalMoves.length;
          isOnlyLegal = legalMoves.length === 1;
        } catch (e) {}

        const isRecapture = k > 0 &&
                            !!move.captured &&
                            !!movesHistory[k-1]?.captured &&
                            move.to === movesHistory[k-1]?.to;

        const isSkipped = false; // Always false since Rule 2 system is removed

        let skipReason = "";

        // Win-Chance Decay based CPL & Accuracy calculation (CAPS v2 Standard)
        const pEvalBefore = evalBefore * (playerColor === 'w' ? 1 : -1);
        const pEvalAfter = evalAfter * (playerColor === 'w' ? 1 : -1);

        const getWinChance = (val: number): number => {
          return 0.5 + 0.5 * Math.tanh(val / 363.95);
        };

        const wcBefore = getWinChance(pEvalBefore);
        const wcAfter = getWinChance(pEvalAfter);

        let loss = wcBefore - wcAfter;
        if (loss < 0) {
          loss = 0;
        }

        let cpl = 0;
        if (isEngineMatch) {
          cpl = 0;
        } else {
          cpl = Math.max(0, pEvalBefore - pEvalAfter);
        }

        // SACRIFICE HEURISTIC FOR BRILLIANT MOVE
        const isSacrifice = !!move.captured && (
          (move.piece === 'q' && move.captured !== 'q') ||
          (move.piece === 'r' && !['q', 'r'].includes(move.captured)) ||
          (move.piece === 'b' && move.captured === 'p') ||
          (move.piece === 'n' && move.captured === 'p')
        );

        // DIFFICULTY HEURISTIC FOR GREAT MOVE
        const isHardPosition = playerColor === 'w' ? (evalBefore < -150) : (evalBefore > 150);

        // Move classifications aligned with Chess.com and Lichess
        let moveClass: 'Brilliant' | 'Great' | 'Best' | 'Good' | 'Inaccuracy' | 'Mistake' | 'Blunder' | 'Book' | 'Forced' = 'Good';
        if (isSkipped) {
          if (k < 16) {
            moveClass = 'Book';
          } else {
            moveClass = 'Forced';
          }
        } else if (isEngineMatch) {
          if (isSacrifice) {
            moveClass = 'Brilliant';
          } else if (isHardPosition) {
            moveClass = 'Great';
          } else {
            moveClass = 'Best';
          }
        } else {
          if (cpl <= 10) {
            moveClass = 'Best';
          } else if (cpl <= 40) {
            moveClass = 'Good';
          } else if (cpl <= 100) {
            moveClass = 'Inaccuracy';
          } else if (cpl <= 250) {
            moveClass = 'Mistake';
          } else {
            moveClass = 'Blunder';
          }
        }

        // Calculate move accuracy [0, 100] using standard win-chance decay
        let moveAccuracy = 100;
        if (isSkipped) {
          moveAccuracy = 100;
        } else if (isEngineMatch || moveClass === 'Brilliant' || moveClass === 'Great') {
          moveAccuracy = 100;
        } else {
          moveAccuracy = Math.round(100 * Math.exp(-3.5 * loss) * 10) / 10;
        }

        // Clock Times Extraction
        const rawClockVal = clocks[k];
        let clockSpent: number | null = null;
        
        if (rawClockVal !== null) {
          const moveInColorIndex = Math.floor(k / 2);
          const sameColorClocks = clocks.filter((_, idx) => idx % 2 === (playerColor === 'w' ? 0 : 1));
          
          if (moveInColorIndex === 0) {
            clockSpent = Math.max(0, baseTime - rawClockVal);
          } else {
            const prevClock = sameColorClocks[moveInColorIndex - 1];
            if (prevClock !== null) {
              clockSpent = Math.max(0, prevClock - rawClockVal);
            }
          }
        }

        moveAnalyses.push({
          san: move.san,
          uci: playedUci,
          color: playerColor,
          evalBefore: evalBefore,
          evalAfter: evalAfter,
          cpl: cpl,
          accuracy: moveAccuracy,
          moveClass: moveClass,
          bestmove: engineBest,
          clock: rawClockVal,
          timeSpent: clockSpent,
          isEngineMatch: isEngineMatch,
          complexity: complexity,
          isSkipped: isSkipped,
          skipReason: skipReason || undefined
        });
      }

      // Compile Player-specific aggregates
      const computeStats = (side: 'w' | 'b'): PlayerStats => {
        const sideMoves = moveAnalyses.filter(m => m.color === side);
        const lCount = sideMoves.length;
        
        if (lCount === 0) {
          return {
            accuracy: 0, acpl: 0, bestMoveMatchPercent: 0,
            brilliantCount: 0, greatMoveCount: 0, bestMoveCount: 0, goodMoveCount: 0,
            inaccuracyCount: 0, mistakeCount: 0, blunderCount: 0,
            times: [], avgTimeSpent: 0, sdTimeSpent: 0, hasClocks: false,
            isFlatTime: false, suspiciousScore: 0
          };
        }

        // Calculate ACPL and CAPS v2 Accuracy as average of move-by-move accuracies
        const activeMoves = sideMoves.filter(m => !m.isSkipped);
        const activeCount = activeMoves.length;

        const totalCpl = activeMoves.reduce((acc, m) => acc + m.cpl, 0);
        const acpl = activeCount > 0 ? (totalCpl / activeCount) : 0;
        
        // Average precision of each position
        const totalAccuracy = activeMoves.reduce((acc, m) => acc + m.accuracy, 0);
        const accuracy = activeCount > 0
          ? Math.min(100, Math.max(0, Math.round((totalAccuracy / activeCount) * 10) / 10))
          : 100;

        const brilliantCount = sideMoves.filter(m => m.moveClass === 'Brilliant').length;
        const greatMoveCount = sideMoves.filter(m => m.moveClass === 'Great').length;
        const bestMoveCount = sideMoves.filter(m => m.moveClass === 'Best').length;
        const goodMoveCount = sideMoves.filter(m => m.moveClass === 'Good').length;
        const inaccuracyCount = sideMoves.filter(m => m.moveClass === 'Inaccuracy').length;
        const mistakeCount = sideMoves.filter(m => m.moveClass === 'Mistake').length;
        const blunderCount = sideMoves.filter(m => m.moveClass === 'Blunder').length;
        
        // Rule 4: Best Move Match % vs Top 1 Engine on activemoves choice-based options
        const activeMatches = activeMoves.filter(m => m.isEngineMatch).length;
        const bestMoveMatchPercent = activeCount > 0 ? (activeMatches / activeCount) * 100 : 0;

        // Times statistics
        const sideTimeSpent = sideMoves.map(m => m.timeSpent).filter((t): t is number => t !== null);
        const hasClocks = sideTimeSpent.length > 2;
        const avgTimeSpent = hasClocks ? (sideTimeSpent.reduce((a, b) => a + b, 0) / sideTimeSpent.length) : 0;
        const sdTimeSpent = hasClocks ? getStandardDeviation(sideTimeSpent) : 0;

        // Rule 5: FLAG FLAT TIME jika SD < 1.5 detik dan langkah > 20
        const isFlatTime = hasClocks && sdTimeSpent < 1.5 && lCount > 20;

        // Rule 6: Suspicious Score perkawinan CPL < 20 AND Waktu < 4s AND Complexity > 100
        const suspiciousScore = sideMoves.filter(m => 
          !m.isSkipped &&
          m.cpl < 20 &&
          m.timeSpent !== null &&
          m.timeSpent < 4 &&
          m.complexity > 100
        ).length;

        return {
          accuracy,
          acpl: Math.round(acpl * 10) / 10,
          bestMoveMatchPercent,
          brilliantCount,
          greatMoveCount,
          bestMoveCount,
          goodMoveCount,
          inaccuracyCount,
          mistakeCount,
          blunderCount,
          times: sideTimeSpent,
          avgTimeSpent: Math.round(avgTimeSpent * 10) / 10,
          sdTimeSpent: Math.round(sdTimeSpent * 10) / 10,
          hasClocks,
          isFlatTime,
          suspiciousScore
        };
      };

      const finalWhiteStats = computeStats('w');
      const finalBlackStats = computeStats('b');

      const dateStr = headers.Date || new Date().toISOString().split('T')[0];
      const eventStr = headers.Event || "Gambit Kopi Chess Tournament";

      const finalResults: AnalysisResults = {
        whiteName: headers.White || "Pemain Putih",
        blackName: headers.Black || "Pemain Hitam",
        whiteRating,
        blackRating,
        date: dateStr,
        event: eventStr,
        whiteStats: finalWhiteStats,
        blackStats: finalBlackStats,
        moves: moveAnalyses
      };

      // Persistence
      localStorage.setItem('gambit_kopi_last_pgn', pgn);
      
      setResults(finalResults);
      setIsAnalyzing(false);

      // Trigger Red-card warning banner popup recommendations if applicable
      const whiteVerdict = calculateVerdict(finalResults, 'w');
      const blackVerdict = calculateVerdict(finalResults, 'b');
      
      if (whiteVerdict.status === 'RED' || blackVerdict.status === 'RED') {
        showToastNotification("Rekomendasi Panitia: Diskualifikasi + Simpan Bukti Ini 🔴");
      } else {
        showToastNotification("Analisis Selesai! Selamat ngopi ☕");
      }

    } catch (err: any) {
      setIsAnalyzing(false);
      setProgressStep(0);
      if (stockfishRef.current) {
        stockfishRef.current.terminate();
        stockfishRef.current = null;
      }
      activeWorkersRef.current.forEach((w) => {
        try {
          w.terminate();
        } catch (e) {}
      });
      activeWorkersRef.current = [];
      alert(`Analisis gagal: ${err.message || "Pastikan format PGN sesuai standar."}`);
    }
  };

  // ==========================================
  // THRESHOLD & 3-COLOR VERDICT LOGIC
  // ==========================================

  const calculateVerdict = (res: AnalysisResults, side: 'w' | 'b'): Verdict => {
    const stats = side === 'w' ? res.whiteStats : res.blackStats;
    const rating = side === 'w' ? res.whiteRating : res.blackRating;
    const { accuracy, acpl, blunderCount, bestMoveMatchPercent, sdTimeSpent, hasClocks, suspiciousScore, isFlatTime } = stats;

    let isRed = false;
    let isYellow = false;

    // Thresholds combining ACPL, Best Move Match, Flat Time, and Rating
    if (rating < 1000) {
      if (acpl <= 12 || bestMoveMatchPercent >= 80 || (accuracy >= 93 && isFlatTime)) isRed = true;
      else if (acpl <= 22 || bestMoveMatchPercent >= 70 || accuracy >= 90) isYellow = true;
    } else if (rating >= 1000 && rating <= 1500) {
      if (acpl <= 10 || bestMoveMatchPercent >= 82 || (accuracy >= 94 && isFlatTime)) isRed = true;
      else if (acpl <= 20 || bestMoveMatchPercent >= 72 || accuracy >= 91) isYellow = true;
    } else if (rating > 1500 && rating <= 2000) {
      if (acpl <= 8 || bestMoveMatchPercent >= 85 || (accuracy >= 96 && isFlatTime)) isRed = true;
      else if (acpl <= 16 || bestMoveMatchPercent >= 75 || accuracy >= 93) isYellow = true;
    } else { // > 2000
      if (acpl <= 6 || bestMoveMatchPercent >= 90 || (accuracy >= 98 && isFlatTime)) isRed = true;
      else if (acpl <= 12 || bestMoveMatchPercent >= 80 || accuracy >= 95) isYellow = true;
    }

    // Direct overrides based on Suspicious Score and Flat Time
    if (suspiciousScore > 8 || (suspiciousScore > 5 && isFlatTime)) {
      isRed = true;
    }

    // Rule 6: "Jika Skor (suspiciousScore) > 5, otomatis KUNING minimal."
    if (suspiciousScore > 5) {
      isYellow = true;
    }

    // Direct Red override for extreme matches or absolute flat time + high matches on long games
    if (bestMoveMatchPercent > 88 || (isFlatTime && bestMoveMatchPercent > 82)) {
      isRed = true;
    }

    if (isRed) {
      return {
        status: 'RED',
        title: '🔴 TERDETEKSI - INDIKASI KUAT ENGINE',
        reason: `Akurasi ${accuracy}% (ACPL: ${acpl}, Match: ${bestMoveMatchPercent.toFixed(1)}%) sangat tidak wajar untuk rating ${rating}. Ditemukan ${suspiciousScore} langkah taktis instan mencurigakan pada posisi rumit${isFlatTime ? ' disertai keseragaman durasi berpikir ekstrim (Flat Time)' : ''}. Pola berpikir kuat terindikasi bantuan komputer.`,
        badgeClass: 'bg-white/20 text-white border border-white/35',
        boxClass: 'bg-[#fa412d] border-2 border-white/20 text-white shadow-2xl relative'
      };
    } else if (isYellow) {
      return {
        status: 'YELLOW',
        title: '🟡 RAWAN - PERLU PENGAWASAN',
        reason: `Ditemukan beberapa anomali taktis pada game ini: ${suspiciousScore} langkah kilat mencurigakan pada posisi kompleks${isFlatTime ? ' dengan durasi flat' : ''}. Total akurasi ${accuracy}% (ACPL: ${acpl}, Match: ${bestMoveMatchPercent.toFixed(1)}%). Panitia disarankan mengecek rekam jejak pemain.`,
        badgeClass: 'bg-black/20 text-black border border-black/20',
        boxClass: 'bg-[#f7c631] border-2 border-black/10 text-black shadow-2xl relative'
      };
    } else {
      return {
        status: 'GREEN',
        title: '🟢 AMAN - POLA MANUSIA NORMAL',
        reason: `Statistik pergerakan sepenuhnya konsisten dengan pola berpikir manusia normal. Akurasi ${accuracy}% (ACPL: ${acpl}, Match: ${bestMoveMatchPercent.toFixed(1)}%) dengan variansi waktu berpikir wajar.`,
        badgeClass: 'bg-white/20 text-white border border-white/35',
        boxClass: 'bg-[#81b64c] border-2 border-white/20 text-white shadow-2xl relative'
      };
    }
  };

  // ==========================================
  // EXPORT / UTILITY FUNCTIONS
  // ==========================================

  const copySummaryToClipboard = () => {
    if (!results) return;

    const wVerdict = calculateVerdict(results, 'w');
    const bVerdict = calculateVerdict(results, 'b');

    const summaryText = `☕ GAMBIT KOPI CHESS ANALYZER REPORT
========================================
Event: ${results.event}
Tanggal: ${results.date}

PUTIH: ${results.whiteName} (${results.whiteRating})
VONIS PUTIH: ${wVerdict.title}
Akurasi: ${results.whiteStats.accuracy}%
ACPL: ${results.whiteStats.acpl} cpl
Kesesuaian Engine: ${results.whiteStats.bestMoveMatchPercent.toFixed(1)}%
Alasan: ${wVerdict.reason}

----------------------------------------

HITAM: ${results.blackName} (${results.blackRating})
VONIS HITAM: ${bVerdict.title}
Akurasi: ${results.blackStats.accuracy}%
ACPL: ${results.blackStats.acpl} cpl
Kesesuaian Engine: ${results.blackStats.bestMoveMatchPercent.toFixed(1)}%
Alasan: ${bVerdict.reason}

========================================
Laporan diolah secara 100% klon client-side oleh Panitia Gambit Kopi.
Bukan bukti hukum mutlak, hanya alat bantu kalkulasi statistik kecurangan.`;

    navigator.clipboard.writeText(summaryText)
      .then(() => {
        showToastNotification("Ringkasan analisis disalin ke clipboard! 📋");
      })
      .catch(() => {
        alert("Gagal menyalin teks ringkasan.");
      });
  };

  const exportPDFReport = async () => {
    const reportElement = document.getElementById('dashboard-report');
    if (!reportElement) return;

    showToastNotification("Sedang menggiling laporan PDF... Harap tunggu ☕");

    try {
      const canvas = await html2canvas(reportElement, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#1a1614',
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = 210;
      const pdfHeight = 297;
      const computedHeight = (canvas.height * pdfWidth) / canvas.width;
      
      let positionY = 0;
      let heightRemaining = computedHeight;

      pdf.addImage(imgData, 'PNG', 0, positionY, pdfWidth, computedHeight);
      heightRemaining -= pdfHeight;

      while (heightRemaining > 0) {
        positionY = heightRemaining - computedHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, positionY, pdfWidth, computedHeight);
        heightRemaining -= pdfHeight;
      }

      pdf.save(`GambitKopi_Report_${results?.whiteName}_vs_${results?.blackName}.pdf`);
      showToastNotification("Laporan PDF berhasil diunduh! 📄");
    } catch (e) {
      console.error(e);
      alert("Gagal mencetak PDF. Silakan ulangi kembali.");
    }
  };

  // Convert pairs into tabular row entries
  const getMovePairs = (moves: MoveAnalysis[]) => {
    const pairs: { index: number; white: MoveAnalysis | null; black: MoveAnalysis | null }[] = [];
    for (let i = 0; i < moves.length; i += 2) {
      pairs.push({
        index: Math.floor(i / 2) + 1,
        white: moves[i] || null,
        black: moves[i + 1] || null
      });
    }
    return pairs;
  };

  // Card sub-badge configuration for accurate visual representation
  const getSubBadgeColor = (val: 'Brilliant' | 'Great' | 'Best' | 'Good' | 'Inaccuracy' | 'Mistake' | 'Blunder' | 'Book' | 'Forced') => {
    switch (val) {
      case 'Brilliant': return 'bg-cyan-500 text-white';
      case 'Great': return 'bg-teal-500 text-white';
      case 'Best': return 'bg-[#81b64c] text-white';
      case 'Good': return 'bg-amber-600 text-white';
      case 'Inaccuracy': return 'bg-[#f7c631] text-black';
      case 'Mistake': return 'bg-orange-500 text-white';
      case 'Blunder': return 'bg-[#fa412d] text-white';
      case 'Book': return 'bg-blue-600 text-white';
      case 'Forced': return 'bg-zinc-600 text-white';
    }
  };

  // Table row visual class mapping matching the color standard requested
  const getRowClass = (klass: 'Brilliant' | 'Great' | 'Best' | 'Good' | 'Inaccuracy' | 'Mistake' | 'Blunder' | 'Book' | 'Forced') => {
    switch (klass) {
      case 'Brilliant': return 'bg-cyan-950/20 text-cyan-200 border-l-4 border-cyan-500';
      case 'Great': return 'bg-teal-950/20 text-teal-200 border-l-4 border-teal-500';
      case 'Best': return 'bg-green-950/20 text-green-200 border-l-4 border-[#81b64c]';
      case 'Good': return 'hover:bg-amber-950/10 text-[#f5efe6]';
      case 'Inaccuracy': return 'bg-yellow-950/20 text-yellow-200 border-l-4 border-[#f7c631]';
      case 'Mistake': return 'bg-orange-950/20 text-orange-200 border-l-4 border-orange-500';
      case 'Blunder': return 'bg-red-950/20 text-red-200 border-l-4 border-[#fa412d]';
      case 'Book': return 'bg-blue-950/10 text-blue-200 border-l-4 border-blue-500/50';
      case 'Forced': return 'bg-zinc-950/10 text-zinc-300 border-l-4 border-zinc-500/50';
    }
  };

  // Active statistics helper
  const activeStats = results ? (activeTab === 'w' ? results.whiteStats : results.blackStats) : null;
  const activeRating = results ? (activeTab === 'w' ? results.whiteRating : results.blackRating) : 1200;
  const activeName = results ? (activeTab === 'w' ? results.whiteName : results.blackName) : '';

  return (
    <div className="min-h-screen bg-[#1a1614] text-[#f5efe6] font-sans antialiased relative selection:bg-[#8b5a2b] selection:text-white pb-14">
      {/* Decorative Warm Ambient Coffee-Shop Background Light */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-[#8b5a2b] opacity-10 blur-[150px] rounded-full pointer-events-none" />
      <div className="absolute top-1/2 right-10 w-[400px] h-[400px] bg-[#81b64c] opacity-5 blur-[120px] rounded-full pointer-events-none" />

      {/* HEADER SECTION */}
      <header className="sticky top-0 z-40 bg-[#161210]/95 backdrop-blur-md border-b border-[#2b2522] py-4 shadow-xl animate-fade-in">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="text-4xl text-neutral-100">☕♟️</span>
            <div>
              <h1 id="app-title" className="text-xl sm:text-2xl font-bold tracking-tight text-[#8b5a2b] flex items-center gap-2">
                Gambit Kopi Chess Analyzer
              </h1>
              <p className="text-[10px] text-gray-400 font-bold tracking-widest uppercase">
                Tools Panitia Anti-Cheat • Ngopi Dulu, Fair Play Kemudian
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2 text-[10px] font-mono text-[#bdaea5] bg-[#2b2522] px-3 py-1.5 rounded-lg border border-[#8b5a2b]/30">
            <span className="text-[#8b5a2b] font-bold mr-1 uppercase">Status Engine:</span>
            <span className="text-green-400 font-mono uppercase">Stockfish 18 Ready (Parallel)</span>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 mt-6">
        
        {/* INPUT PANEL & SETTINGS CARD */}
        <section id="panel-input" className="bg-[#2b2522] rounded-2xl p-5 md:p-6 shadow-2xl border border-[#3d3430] flex flex-col gap-5">
          {/* Section title */}
          <div className="flex items-center justify-between border-b border-[#3d3430] pb-3">
            <h2 className="text-base sm:text-lg font-semibold flex items-center gap-2">
              <span className="text-lg">⚙️</span> Konfigurasi PGN & Parameter Analisis
            </h2>
            <button
              onClick={() => {
                setPgn(DEFAULT_PGN);
                showToastNotification("PGN Default dimuat ulang! 📋");
              }}
              className="text-xs text-[#bdaea5] hover:text-[#8b5a2b] transition flex items-center gap-1.5 pl-3 py-1"
            >
              <RefreshCw size={12} /> Reset PGN Default
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* PGN Textbox */}
            <div className="lg:col-span-8 flex flex-col gap-2">
              <label htmlFor="pgn-input" className="block text-[11px] font-bold text-[#8b5a2b] uppercase tracking-wide">
                Paste PGN Lengkap Di Sini <span className="text-[10px] text-gray-400 font-medium lowercase tracking-normal">(Wajib menyertakan [%clk] untuk analisis durasi berpikir)</span>
              </label>
              <textarea
                id="pgn-input"
                className="w-full h-44 p-4 text-xs font-mono rounded-xl bg-[#1a1614] border border-[#3d3430] text-gray-100 focus:outline-none focus:border-[#8b5a2b] focus:ring-1 focus:ring-[#8b5a2b] transition-all placeholder:text-[#5a4d46]"
                placeholder={DEFAULT_PGN}
                value={pgn}
                onChange={(e) => setPgn(e.target.value)}
              />
            </div>

            {/* Side options */}
            <div className="lg:col-span-4 flex flex-col gap-4">
              <div className="grid grid-cols-2 lg:grid-cols-1 gap-4">
                {/* White Rating input */}
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="rating-white" className="block text-[10px] font-bold text-gray-400 uppercase tracking-wide">
                    Rating Putih
                  </label>
                  <input
                    id="rating-white"
                    type="number"
                    min="1"
                    max="4000"
                    className="w-full bg-[#1a1614] border border-[#3d3430] py-2.5 px-3 rounded text-sm font-semibold text-white focus:outline-none focus:border-[#8b5a2b]"
                    value={whiteRating}
                    onChange={(e) => setWhiteRating(parseInt(e.target.value, 10) || 1200)}
                  />
                </div>

                {/* Black Rating input */}
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="rating-black" className="block text-[10px] font-bold text-gray-400 uppercase tracking-wide">
                    Rating Hitam
                  </label>
                  <input
                    id="rating-black"
                    type="number"
                    min="1"
                    max="4000"
                    className="w-full bg-[#1a1614] border border-[#3d3430] py-2.5 px-3 rounded text-sm font-semibold text-white focus:outline-none focus:border-[#8b5a2b]"
                    value={blackRating}
                    onChange={(e) => setBlackRating(parseInt(e.target.value, 10) || 1200)}
                  />
                </div>
              </div>

              {/* Depth Engine list */}
              <div className="flex flex-col gap-1.5">
                <label htmlFor="engine-depth-selector" className="block text-[10px] font-bold text-gray-400 uppercase tracking-wide">
                  Depth Engine
                </label>
                <select
                  id="engine-depth-selector"
                  className="w-full bg-[#1a1614] border border-[#3d3430] py-2.5 px-3 rounded text-sm text-gray-100 focus:outline-none focus:border-[#8b5a2b] appearance-none"
                  value={engineDepth}
                  onChange={(e) => setEngineDepth(parseInt(e.target.value, 10))}
                >
                  <option value="12" className="bg-[#1a1614]">12 - Cepat (Analisis Kilat - 400ms/langkah)</option>
                  <option value="15" className="bg-[#1a1614]">15 - Standar (Direkomendasikan - 800ms/langkah)</option>
                  <option value="18" className="bg-[#1a1614]">18 - Akurat (Style Stockfish 18 - 2.0s/langkah)</option>
                  <option value="20" className="bg-[#1a1614]">20 - Presisi Ekstrem (Chess.com/Lichess Style - 3.0s/langkah)</option>
                </select>
                <p className="text-[10px] text-amber-500/80 italic leading-snug mt-0.5">
                  {engineDepth === 20
                    ? '🔥 Mode Presisi Ekstrem: Pencarian sedalam 20 langkah sekelas Lichess/Chess.com (3.0s/langkah) untuk hasil evaluasi taktis terdalam.'
                    : engineDepth === 18
                      ? '⚡ Mode Akurat Stockfish 18: Maksimal 2.0s/langkah berkat optimisasi 4-Core paralel, hasil super tajam!'
                      : engineDepth === 15
                        ? '⚡ Mode Standar: Maksimal 800ms/langkah untuk keseimbangan kecepatan kilat dan ketelitian analisis.'
                        : '⚡ Mode Analisis Kilat: Maksimal 400ms/langkah untuk evaluasi cepat seluruh PGN.'}
                </p>
              </div>

              {/* ACTION BUTTONS */}
              <div className="flex gap-2.5 mt-auto pt-2">
                {!isAnalyzing ? (
                  <button
                    id="btn-start"
                    onClick={() => setShowWarningModal(true)}
                    className="w-full bg-[#8b5a2b] hover:bg-[#a16b36] text-white py-3 px-4 rounded-lg font-bold transition-all shadow-lg shadow-[#8b5a2b]/10 flex items-center justify-center gap-2 group cursor-pointer"
                  >
                    <span>☕ Seduh Analisis</span>
                  </button>
                ) : (
                  <button
                    id="btn-stop"
                    onClick={() => {
                      if (stockfishRef.current) {
                        stockfishRef.current.terminate();
                        stockfishRef.current = null;
                      }
                      activeWorkersRef.current.forEach((w) => {
                        try {
                          w.terminate();
                        } catch (e) {}
                      });
                      activeWorkersRef.current = [];
                      setIsAnalyzing(false);
                      showToastNotification("Analisis dibatalkan secara paksa 🛑");
                    }}
                    className="w-full bg-[#fa412d] hover:bg-[#fa412d]/90 text-white py-3 px-4 rounded-lg font-bold transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer animate-pulse"
                  >
                    <X size={16} /> Stop Analisis
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* PROGRESS BAR DISPLAY */}
          {isAnalyzing && (
            <div className="mt-4 p-4 rounded-xl bg-[#161210] border border-[#3d3430] flex flex-col gap-3">
              <div className="flex justify-between items-center text-xs">
                <span className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#8b5a2b] animate-ping" />
                  Mengekstrak catur & mengevaluasi langkah <span className="font-semibold text-white">{progressStep}/{progressTotal}</span>...
                </span>
                <span className="font-mono text-[#8b5a2b]">EVAL: {currentEvalProgress} cp</span>
              </div>
              
              <div className="w-full bg-[#2b2522] h-2.5 rounded-full overflow-hidden">
                <div 
                  className="bg-[#8b5a2b] h-full transition-all duration-300"
                  style={{ width: `${(progressStep / progressTotal) * 100}%` }}
                />
              </div>

              <div className="text-[10px] text-[#bdaea5] italic flex justify-center items-center gap-1.5">
                ☕ Stockfish sedang menyeduh data. Jangan menutup tab browser ini, nikmati kopi Anda dulu...
              </div>
            </div>
          )}
        </section>

        {/* LOADING ENGINE MODAL INDICATOR */}
        <AnimatePresence>
          {showWarningModal && (
            <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <motion.div 
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                className="bg-[#2b2522] border border-[#3d3430] max-w-md w-full p-6 rounded-2xl shadow-2xl relative"
              >
                <div className="flex items-center justify-between border-b border-[#3d3430] pb-3 mb-4">
                  <h3 id="modal-title" className="text-lg font-bold flex items-center gap-2 text-white">
                    ☕ Seduh Analisis Baru
                  </h3>
                  <button 
                    onClick={() => setShowWarningModal(false)}
                    className="text-[#bdaea5] hover:text-white transition"
                  >
                    <X size={18} />
                  </button>
                </div>

                <div className="flex flex-col gap-4 text-sm text-[#bdaea5]">
                  <p>
                    Anda akan memulai analisis catur anti-cheat menggunakan engine <strong className="text-white">Stockfish.wasm</strong> secara lokal sepenuhnya di browser Anda.
                  </p>
                  
                  <div className="p-3 bg-[#161210] rounded-xl border border-[#3d3430] flex gap-3 text-amber-500">
                    <AlertTriangle size={24} className="shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-xs text-[#f5efe6]">PERINGATAN WAKTU PROSES</p>
                      <p className="text-xs text-[#bdaea5] mt-1">
                        Proses ini memakan waktu sekitar <strong className="text-white">30-90 detik</strong> dependiendo pada panjang permainan. Jangan tutup tab atau minimize browser. Sambil nunggu, seduh kopi dulu ☕.
                      </p>
                    </div>
                  </div>

                  <p className="text-xs">
                    *Kalkulasi murni client-side tanpa data yang dikirim ke server catur eksternal manapun. Keamanan data terjamin.
                  </p>
                </div>

                <div className="flex gap-3 mt-6">
                  <button
                    onClick={() => setShowWarningModal(false)}
                    className="flex-1 border border-[#3d3430] text-[#bdaea5] py-2.5 rounded-xl text-xs hover:bg-[#161210] transition"
                  >
                    Kembali
                  </button>
                  <button
                    onClick={analyzeGame}
                    className="flex-1 bg-[#8b5a2b] text-white py-2.5 rounded-xl text-xs font-semibold hover:bg-[#a06d3b] transition"
                  >
                    Mulai Seduh ☕
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* RESULTS REPORT DASHBOARD CONTAINER */}
        {results ? (
          <motion.div 
            initial={{ opacity: 0, y: 15 }} 
            animate={{ opacity: 1, y: 0 }} 
            id="dashboard-report" 
            className="mt-8 flex flex-col gap-6"
          >
            {/* IN-APP DASHBOARD UTILITY ACTION BAR */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-[#2b2522] rounded-xl p-3 border border-[#3d3430]">
              <span className="text-xs text-[#bdaea5] font-mono">
                LAPORAN DIGILING: <strong className="text-white">{results.date}</strong> | TOURNAMENT: <strong className="text-white">{results.event}</strong>
              </span>

              <div className="flex items-center gap-2">
                <button
                  id="btn-copy"
                  onClick={copySummaryToClipboard}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#161210] hover:bg-[#1f1a18] text-[#f5efe6] text-xs font-medium cursor-pointer transition border border-[#3d3430]"
                >
                  <Copy size={13} className="text-[#8b5a2b]" /> Salin Ringkasan
                </button>
                <button
                  id="btn-download"
                  onClick={exportPDFReport}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#8b5a2b] hover:bg-[#a06d3b] text-white text-xs font-semibold cursor-pointer transition shadow-md shadow-[#8b5a2b]/10"
                >
                  <Download size={13} /> Download Laporan PDF
                </button>
              </div>
            </div>

            {/* SECTION 1: KARTU VONIS BESAR (DUAL PLAYERS - SIDE BY SIDE) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* White Player Verdict */}
              {(() => {
                const verdict = calculateVerdict(results, 'w');
                const isYellow = verdict.status === 'YELLOW';
                return (
                  <div className={`p-6 rounded-2xl ${verdict.boxClass} flex flex-col gap-3 justify-between relative overflow-hidden h-full min-h-[220px]`}>
                    <div className="absolute -right-6 -top-6 text-8xl opacity-10 pointer-events-none rotate-12">⚠️</div>
                    <div>
                      <div className="flex items-center justify-between mb-4">
                        <span className={`text-[10px] font-mono font-black uppercase tracking-widest px-2.5 py-1 rounded-md border ${
                          isYellow ? 'text-black/60 bg-black/5 border-black/10' : 'text-white/60 bg-white/5 border-white/10'
                        }`}>PUTIH (WHITE)</span>
                        <span className={`text-[10px] font-black font-mono px-2.5 py-0.5 rounded-full ${verdict.badgeClass}`}>
                          STATUS: {verdict.status}
                        </span>
                      </div>
                      <h3 id="verdict-title-white" className={`text-xl md:text-2xl font-black uppercase tracking-tight ${isYellow ? 'text-black' : 'text-white'}`}>
                        {results.whiteName} <span className={isYellow ? 'text-black/60 text-sm' : 'text-white/60 text-sm'}>({results.whiteRating})</span>
                      </h3>
                      <h4 className={`text-sm font-extrabold mt-1.5 uppercase tracking-wide ${isYellow ? 'text-black/90' : 'text-white'}`}>
                        {verdict.title}
                      </h4>
                      <p className={`text-xs mt-3 leading-relaxed ${isYellow ? 'text-black/85 font-medium' : 'text-white/90 font-light'}`}>
                        {verdict.reason}
                      </p>
                    </div>
                  </div>
                );
              })()}

              {/* Black Player Verdict */}
              {(() => {
                const verdict = calculateVerdict(results, 'b');
                const isYellow = verdict.status === 'YELLOW';
                return (
                  <div className={`p-6 rounded-2xl ${verdict.boxClass} flex flex-col gap-3 justify-between relative overflow-hidden h-full min-h-[220px]`}>
                    <div className="absolute -right-6 -top-6 text-8xl opacity-10 pointer-events-none rotate-12">⚠️</div>
                    <div>
                      <div className="flex items-center justify-between mb-4">
                        <span className={`text-[10px] font-mono font-black uppercase tracking-widest px-2.5 py-1 rounded-md border ${
                          isYellow ? 'text-black/60 bg-black/5 border-black/10' : 'text-white/60 bg-white/5 border-white/10'
                        }`}>HITAM (BLACK)</span>
                        <span className={`text-[10px] font-black font-mono px-2.5 py-0.5 rounded-full ${verdict.badgeClass}`}>
                          STATUS: {verdict.status}
                        </span>
                      </div>
                      <h3 id="verdict-title-black" className={`text-xl md:text-2xl font-black uppercase tracking-tight ${isYellow ? 'text-black' : 'text-white'}`}>
                        {results.blackName} <span className={isYellow ? 'text-black/60 text-sm' : 'text-white/60 text-sm'}>({results.blackRating})</span>
                      </h3>
                      <h4 className={`text-sm font-extrabold mt-1.5 uppercase tracking-wide ${isYellow ? 'text-black/90' : 'text-white'}`}>
                        {verdict.title}
                      </h4>
                      <p className={`text-xs mt-3 leading-relaxed ${isYellow ? 'text-black/85 font-medium' : 'text-white/90 font-light'}`}>
                        {verdict.reason}
                      </p>
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* TAB SELECTION TO CHANGE METRIC SCORES AND CHARTS DETAIL */}
            <div className="bg-[#2b2522] rounded-2xl p-4 border border-[#3d3430] flex flex-col gap-6">
              
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-[#3d3430] pb-4">
                <div className="flex items-center gap-2">
                  <span className="text-[#8b5a2b]"><BarChart4 size={18} /></span>
                  <h3 className="text-sm font-semibold text-white uppercase tracking-wider">Metrik & Review Terperinci</h3>
                </div>

                {/* Sub toggle for White or Black */}
                <div className="bg-[#161210] p-1 rounded-lg border border-[#3d3430] flex w-full sm:w-auto">
                  <button
                    onClick={() => setActiveTab('w')}
                    className={`flex-1 sm:flex-none py-1.5 px-4 rounded text-xs px-5 font-semibold tracking-wide transition-all uppercase cursor-pointer ${
                      activeTab === 'w' ? 'bg-[#8b5a2b] text-white shadow-md' : 'text-[#bdaea5] hover:text-white'
                    }`}
                  >
                    ⚪ Putih: {results.whiteName}
                  </button>
                  <button
                    onClick={() => setActiveTab('b')}
                    className={`flex-1 sm:flex-none py-1.5 px-4 rounded text-xs px-5 font-semibold tracking-wide transition-all uppercase cursor-pointer ${
                      activeTab === 'b' ? 'bg-[#8b5a2b] text-white shadow-md' : 'text-[#bdaea5] hover:text-white'
                    }`}
                  >
                    ⚫ Hitam: {results.blackName}
                  </button>
                </div>
              </div>

              {/* SECTION 2: 8 KARTU METRIK */}
              {activeStats && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {/* Card 1: Accuracy */}
                  <div className="bg-[#1a1614] p-3.5 rounded-lg border border-[#3d3430] flex flex-col justify-between h-20 relative overflow-hidden">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] text-gray-500 uppercase font-black">Accuracy</span>
                      <span className={`text-[10px] px-1.5 rounded ${
                        activeStats.accuracy >= 95 ? 'bg-[#fa412d] text-white' : activeStats.accuracy >= 88 ? 'bg-[#f7c631] text-black' : 'bg-[#81b64c] text-white'
                      }`}>{activeStats.accuracy >= 95 ? '🔴' : activeStats.accuracy >= 88 ? '🟡' : '🟢'}</span>
                    </div>
                    <div className="text-xl font-bold text-gray-100">{activeStats.accuracy}%</div>
                  </div>

                  {/* Card 2: ACPL */}
                  <div className="bg-[#1a1614] p-3.5 rounded-lg border border-[#3d3430] flex flex-col justify-between h-20 relative overflow-hidden">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] text-gray-500 uppercase font-black">ACPL</span>
                      <span className={`text-[10px] px-1.5 rounded ${
                        activeStats.acpl < 12 ? 'bg-[#fa412d] text-white' : 'bg-[#81b64c] text-white'
                      }`}>{activeStats.acpl < 12 ? '🔴' : '🟢'}</span>
                    </div>
                    <div className="text-xl font-bold text-gray-100">{activeStats.acpl} <span className="text-xs font-normal opacity-50">cp</span></div>
                  </div>

                  {/* Card 3: Match Engine */}
                  <div className="bg-[#1a1614] p-3.5 rounded-lg border border-[#3d3430] flex flex-col justify-between h-20 relative overflow-hidden">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] text-gray-500 uppercase font-black">Match Engine</span>
                      <span className={`text-[10px] px-1.5 rounded ${
                        activeStats.bestMoveMatchPercent > 80 ? 'bg-[#fa412d] text-white' : 'bg-[#81b64c] text-white'
                      }`}>{activeStats.bestMoveMatchPercent > 80 ? '🔴' : '🟢'}</span>
                    </div>
                    <div className="text-xl font-bold text-gray-100">{activeStats.bestMoveMatchPercent.toFixed(1)}%</div>
                  </div>

                  {/* Card 4: Suspicious Moves */}
                  <div className="bg-[#1a1614] p-3.5 rounded-lg border border-[#3d3430] flex flex-col justify-between h-20 relative overflow-hidden">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] text-gray-500 uppercase font-black">Suspicious Pt</span>
                      <span className={`text-[10px] px-1.5 rounded ${
                        (activeStats.suspiciousScore || 0) > 5 ? 'bg-[#fa412d] text-white animate-pulse' : (activeStats.suspiciousScore || 0) > 2 ? 'bg-[#f7c631] text-black' : 'bg-[#81b64c] text-white'
                      }`}>{((activeStats.suspiciousScore || 0) > 5) ? '🔴' : ((activeStats.suspiciousScore || 0) > 2 ? '🟡' : '🟢')}</span>
                    </div>
                    <div className="text-xl font-bold text-gray-100">{(activeStats.suspiciousScore || 0)} <span className="text-[9px] font-normal opacity-50">moves</span></div>
                  </div>

                  {/* Card 5: Blunders */}
                  <div className="bg-[#1a1614] p-3.5 rounded-lg border border-[#3d3430] flex flex-col justify-between h-20 relative overflow-hidden">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] text-gray-500 uppercase font-black">Blunders</span>
                      <span className={`text-[10px] px-1.5 rounded ${
                        activeStats.blunderCount > 0 ? 'bg-[#fa412d] text-white' : 'bg-[#81b64c] text-white'
                      }`}>{activeStats.blunderCount > 0 ? '🔴' : '🟢'}</span>
                    </div>
                    <div className="text-xl font-bold text-gray-100">{activeStats.blunderCount}</div>
                  </div>

                  {/* Card 6: Mistakes */}
                  <div className="bg-[#1a1614] p-3.5 rounded-lg border border-[#3d3430] flex flex-col justify-between h-20 relative overflow-hidden">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] text-gray-500 uppercase font-black">Mistakes</span>
                      <span className={`text-[10px] px-1.5 rounded ${
                        activeStats.mistakeCount > 0 ? 'bg-[#fa412d] text-white' : 'bg-[#81b64c] text-white'
                      }`}>{activeStats.mistakeCount > 0 ? '🔴' : '🟢'}</span>
                    </div>
                    <div className="text-xl font-bold text-gray-100">{activeStats.mistakeCount}</div>
                  </div>

                  {/* Card 7: Inaccuracies */}
                  <div className="bg-[#1a1614] p-3.5 rounded-lg border border-[#3d3430] flex flex-col justify-between h-20 relative overflow-hidden">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] text-gray-500 uppercase font-black">Inaccuracies</span>
                      <span className="text-[10px] bg-[#81b64c] text-white px-1.5 rounded">🟢</span>
                    </div>
                    <div className="text-xl font-bold text-gray-100">{activeStats.inaccuracyCount}</div>
                  </div>

                  {/* Card 8: Flat Time */}
                  <div className="bg-[#1a1614] p-3.5 rounded-lg border border-[#3d3430] flex flex-col justify-between h-20 relative overflow-hidden">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] text-gray-500 uppercase font-black">Flat Time</span>
                      <span className={`text-[10px] px-1.5 rounded ${
                        activeStats.isFlatTime ? 'bg-[#fa412d] text-white animate-pulse' : 'bg-[#81b64c] text-white'
                      }`}>{activeStats.isFlatTime ? '🔴 Flat' : '🟢 Normal'}</span>
                    </div>
                    <div className="text-xs font-bold text-gray-100 mt-1">
                      {activeStats.hasClocks ? `SD: ${activeStats.sdTimeSpent}s` : 'No Clock Tag'}
                    </div>
                  </div>
                </div>
              )}

              {/* SECTION 3: GRAFIK MOVE TIMES */}
              {activeStats && (
                <div className="bg-[#161210] p-4 md:p-5 rounded-xl border border-[#3d3430] flex flex-col gap-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#3d3430] pb-3">
                    <div className="flex items-center gap-2">
                       <Clock size={16} className="text-[#8b5a2b]" />
                       <h4 id="chart-title" className="text-xs font-bold uppercase tracking-widest text-[#f5efe6]">Analisis Waktu Pikir</h4>
                    </div>
                    {/* Badge status move variance */}
                    {activeStats.hasClocks ? (
                      <span id="badge-clock-status" className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                        activeStats.sdTimeSpent > 3 ? 'bg-[#81b64c]/20 text-[#81b64c] border border-[#81b64c]' :
                        activeStats.sdTimeSpent >= 1.5 ? 'bg-[#f7c631]/20 text-[#f7c631] border border-[#f7c631]' :
                        'bg-[#fa412d]/20 text-[#fa412d] border border-[#fa412d] animate-pulse'
                      }`}>
                        {activeStats.sdTimeSpent > 3 ? '🟢 Variasi Waktu Normal' :
                         activeStats.sdTimeSpent >= 1.5 ? '🟡 Waktu Terlalu Konsisten' :
                         '🔴 FLAT TIME DETECTED'}
                      </span>
                    ) : (
                      <span className="text-xs text-[#bdaea5] italic">Tidak ada Clock Tag dalam PGN</span>
                    )}
                  </div>

                  {activeStats.hasClocks ? (
                    <div className="flex flex-col gap-3">
                      <div className="h-64 relative block">
                        <canvas ref={chartRef} className="w-full h-full block" />
                      </div>
                      
                      <div className="flex justify-center text-xs text-[#bdaea5] bg-[#2b2522] py-2 px-3 rounded-lg font-mono tracking-wide">
                        Rata-rata: <strong className="text-white mx-1.5">{activeStats.avgTimeSpent}s</strong> | Standar Deviasi (SD): <strong className="text-white mx-1.5">{activeStats.sdTimeSpent}s</strong>
                      </div>
                    </div>
                  ) : (
                    <div className="h-44 rounded-lg bg-[#2b2522]/30 flex flex-col items-center justify-center border border-[#3d3430]/40 text-[#bdaea5] p-6 text-center">
                      <Clock size={36} className="mb-2 opacity-30 text-zinc-400" />
                      <p className="text-xs font-medium">Data waktu pikir tidak tersedia.</p>
                      <p className="text-[10px] opacity-70 mt-1 max-w-sm">
                        PGN yang diupload tidak memiliki tag waktu [%clk] di akhir setiap langkah, sehingga statistik deviasi waktu pikir tidak dapat dirender.
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* SECTION 4: TABEL GAME REVIEW */}
              <div className="bg-[#161210] p-4 rounded-xl border border-[#3d3430] flex flex-col gap-3">
                <div className="flex items-center gap-2 border-b border-[#3d3430] pb-2">
                  <span className="text-[#8b5a2b] font-bold font-mono">♟️</span>
                  <h4 id="table-title" className="text-xs font-bold uppercase tracking-widest text-[#f5efe6]">Tabel Game Review</h4>
                </div>

                <div className="overflow-x-auto rounded-lg border border-[#3d3430]/60 max-h-96">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead className="bg-[#2b2522] text-[#f5efe6] sticky top-0 uppercase font-mono tracking-wider font-semibold">
                      <tr className="border-b border-[#3d3430]">
                        <th className="py-2.5 px-3 font-semibold text-center w-12">#</th>
                        <th className="py-2.5 px-3 font-semibold">Putih (White Move)</th>
                        <th className="py-2.5 px-3 font-semibold text-center w-16">CPL</th>
                        <th className="py-2.5 px-3 font-semibold text-right w-24">Evaluation</th>
                        <th className="py-2.5 px-3 font-semibold">Hitam (Black Move)</th>
                        <th className="py-2.5 px-3 font-semibold text-center w-16">CPL</th>
                        <th className="py-2.5 px-3 font-semibold text-right w-24">Evaluation</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#3d3430]/40 bg-[#1a1614]/80">
                      {getMovePairs(results.moves).map((pair) => (
                        <tr key={pair.index} className="hover:bg-[#2b2522]/30 transition-colors">
                          {/* Move Index */}
                          <td className="py-2 px-3 text-center font-mono font-semibold bg-[#2b2522]/20 border-r border-[#3d3430]/30 text-[#bdaea5]">
                            {pair.index}
                          </td>

                          {/* White playedmove */}
                          {pair.white ? (
                            <td className={`py-2 px-3 ${getRowClass(pair.white.moveClass)}`}>
                              <div className="flex items-center justify-between">
                                <span className="font-mono font-bold font-semibold">{pair.white.san}</span>
                                <div className="flex items-center gap-1.5 shrink-0 pl-2">
                                  {pair.white.isEngineMatch && <span className="text-yellow-400 text-xs shrink-0" title="Rekomendasi Utama Engine">⭐</span>}
                                  <span className={`text-[8px] font-extrabold px-1.5 py-0.2 rounded tracking-widest leading-normal shrink-0 ${getSubBadgeColor(pair.white.moveClass)}`}>
                                    {pair.white.moveClass.toUpperCase()}
                                  </span>
                                </div>
                              </div>
                              {pair.white.timeSpent !== null && (
                                <span className="text-[10px] text-zinc-500 block font-mono">🕒 {pair.white.timeSpent}s</span>
                              )}
                            </td>
                          ) : (
                            <td className="py-2 px-3 text-zinc-600">-</td>
                          )}

                          {/* White CPL */}
                          <td className="py-2 px-3 text-center font-mono text-[#bdaea5]">
                            {pair.white ? pair.white.cpl : '-'}
                          </td>

                          {/* White Eval value */}
                          <td className="py-2 px-3 text-right font-mono pr-4 text-emerald-400">
                            {pair.white ? (
                              <span className={pair.white.evalAfter >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                                {pair.white.evalAfter >= 1000 ? 'M' : (pair.white.evalAfter / 100).toFixed(2)}
                              </span>
                            ) : '-'}
                          </td>

                          {/* Black playedmove */}
                          {pair.black ? (
                            <td className={`py-2 px-3 ${getRowClass(pair.black.moveClass)}`}>
                              <div className="flex items-center justify-between">
                                <span className="font-mono font-bold font-semibold">{pair.black.san}</span>
                                <div className="flex items-center gap-1.5 shrink-0 pl-2">
                                  {pair.black.isEngineMatch && <span className="text-yellow-400 text-xs shrink-0" title="Rekomendasi Utama Engine">⭐</span>}
                                  <span className={`text-[8px] font-extrabold px-1.5 py-0.2 rounded tracking-widest leading-normal shrink-0 ${getSubBadgeColor(pair.black.moveClass)}`}>
                                    {pair.black.moveClass.toUpperCase()}
                                  </span>
                                </div>
                              </div>
                              {pair.black.timeSpent !== null && (
                                <span className="text-[10px] text-zinc-500 block font-mono">🕒 {pair.black.timeSpent}s</span>
                              )}
                            </td>
                          ) : (
                            <td className="py-2 px-3 text-zinc-600">-</td>
                          )}

                          {/* Black CPL */}
                          <td className="py-2 px-3 text-center font-mono text-[#bdaea5]">
                            {pair.black ? pair.black.cpl : '-'}
                          </td>

                          {/* Black Eval value */}
                          <td className="py-2 px-3 text-right font-mono pr-4 text-[#f5efe6]">
                            {pair.black ? (
                              <span className={pair.black.evalAfter >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                                {pair.black.evalAfter >= 1000 ? 'M' : (pair.black.evalAfter / 100).toFixed(2)}
                              </span>
                            ) : '-'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>

          </motion.div>
        ) : (
          !isAnalyzing && (
            <div className="mt-8 bg-[#2b2522]/30 rounded-2xl p-8 border border-[#3d3430]/50 text-center flex flex-col items-center justify-center gap-4">
              <div className="w-16 h-16 rounded-full bg-[#8b5a2b]/10 flex items-center justify-center text-3xl">☕</div>
              <div>
                <h3 className="text-lg font-bold text-white">Laporan Belum Diseduh</h3>
                <p className="text-sm text-[#bdaea5] max-w-md mx-auto mt-2 leading-relaxed">
                  Tempelkan PGN pertandingan catur Anda, konfigurasi rating pemain, masukkan kedalaman pencarian, dan klik <strong className="text-[#8b5a2b]">Seduh Analisis</strong> untuk memindai rekam kecurangan engine.
                </p>
              </div>
            </div>
          )
        )}

      </main>

      {/* TOAST SYSTEM FEEDBACK */}
      <AnimatePresence>
        {showToast && (
          <div id="toast-notify" className="fixed bottom-5 right-5 z-50">
            <motion.div 
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.95 }}
              className="bg-[#2b2522] border-l-4 border-[#8b5a2b] shadow-2xl p-4 rounded-xl text-xs max-w-sm flex items-start gap-3 border border-[#3d3430]"
            >
              <span className="text-lg shrink-0">☕</span>
              <div className="flex-1">
                <p className="font-bold text-[#f5efe6] tracking-wide">INFORMASI PANITIA</p>
                <p id="toast-text" className="text-[#bdaea5] mt-1 leading-relaxed">{toastMessage}</p>
              </div>
              <button 
                onClick={() => setShowToast(false)}
                className="text-zinc-500 hover:text-white pb-2 transition shrink-0"
              >
                <X size={14} />
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* COMPLIANT LEGIT FOOTER DETAILS */}
      <footer className="mt-14 max-w-6xl mx-auto px-4 border-t border-[#2b2522] pt-6 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-[#bdaea5]">
        <div className="flex items-center gap-2">
          <span>☕</span>
          <p>© 2026 Gambit Kopi Chess Analyzer • Made with love by Panitia Gambit Kopi</p>
        </div>
        <div className="flex items-center gap-1 opacity-70">
          <p className="text-[10px] text-right font-mono italic">
            *Bukan bukti hukum mutlak catur, murni instrumen bantu statistik performa catur panitia.
          </p>
        </div>
      </footer>
    </div>
  );
}
